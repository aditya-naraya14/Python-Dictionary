import json
import difflib
from difflib import get_close_matches
data= json.load(open("data.json"))

def trans(w):
    w=w.lower()
    l=get_close_matches(w,data.keys(),5)
    if w in data:
        return data[w]
    elif w.title() in data:
        return data[w.title()]
    elif w.upper() in data:
        return data[w.upper()]
    elif len(get_close_matches(w, data.keys())) > 0:
        no=1;
        print("Enter From The Choices Below or N if word is not in choices ")
        for i in l:
            print(no," ",i)
            no=no+1
        while 1:
            rpl=input()
            if rpl == "1":
                return data[l[0]]
            elif rpl == "2":
                return data[l[1]]
            elif rpl == "3":
                return data[l[2]]
            elif rpl == "4":
                return data[l[3]]
            elif rpl == "5":
                return data[l[4]]
            elif rpl == "n":
                return "Not The word in above choices"
            else:
                print("Enter a Valid Choice")
    else:
        return("Word Doesn't exits")

word= input("Enter the word : ")
op= trans(word)
if type(op) == list:
    no=1;
    for i in op:
        print(no," ",i)
        no=no+1
else:
    print(op)
